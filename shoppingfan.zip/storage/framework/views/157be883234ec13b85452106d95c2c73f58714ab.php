<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ShoppingFan</title>
  <!-- ---- Bootstrap css--- -->
  <link rel="stylesheet" href="../../css/bootstrap.min.css">
  <!-- ---------- default css --------- -->
  <link rel="stylesheet" href="../../css/login.css" />

</head>

<body>

<div class="main-wrapper">
    <div class="main-card">
        <div class="left-side-wrapper">
            <div class="overlay"></div>

            <div class="learn-more-wrapper">
                <div class="software-eng-text">
                    <span>
                        Vamos quién da más 

                    </span>
                        
                    </div>
            </div>

            <div class="navigation-links">
                    
                    
                <a class="nav-link" href="<?php echo e(route('index')); ?>"><?php echo e(__('Inicio')); ?></a>
            </div>
    </div>

    <div class="right-side-wrapper">
        <div class="inner-wrapper">
          <div class="header-wrapper">
            <span>Iniciar Sesión</span>
          </div>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="input-wrapper form_group">
                            <label><?php echo e(__('Email Address')); ?></label>

                            <div class="input">
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="input-wrapper">
                            <label for="password"><?php echo e(__('Password')); ?></label>

                            <div class="input">
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!--<div class="row mb-3">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div>
                            </div>
                        </div>-->

                       
                            <div class="action-wrapper form-group">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Login')); ?>

                                </button>

                                <?php if(Route::has('password.request')): ?>
                                    <a  href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
        
                    </form>

                    <div class="sign-up-wrapper">
                        <span>Don't have an account? <a href="#">Sign up!</a></span>
                      </div>
          
                      <div class="horizontal-separator"></div>


                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html><?php /**PATH C:\laragon\www\integradora10\resources\views/auth/login.blade.php ENDPATH**/ ?>