<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">ShoppingFan</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <li class="nav-item">
        <a class="nav-link" href="/admin/">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Admin</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="/admin/usuarios">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Usuarios</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="/admin/inventario">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Inventario</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/admin/logs">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Logs</span>
        </a>
    </li>

</ul>
<?php /**PATH C:\laragon\www\integradora10\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>